package com.example.fittingroom

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_my__coupon.*


class My_Coupon : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my__coupon)

        val gv: GlobalVariable = applicationContext as GlobalVariable
        var count1 = gv.getcount()
        var i1:Int=0
        var i2:Int=0+count1

        val listData= mutableListOf<List<String>>()

        val adapter=myAdapter(this,listData)

        main_listview.adapter=adapter
        var back : Button? =null
        back=findViewById(R.id.my_coupon_back)
        back.setOnClickListener{
            var intentP32= Intent(this, fittingroom::class.java)
            startActivityForResult(intentP32,32)
        }

        if (main_listview.getAdapter()!=null) {
            while(i1<i2) {
                //  listData.add(listOf(R.mipmap.ic_launcher_round.toString(), msg))
                listData.add(listOf(R.drawable.coupon2.toString(),"服飾全面85折"))//新增一筆資料到listData
                adapter.notifyDataSetChanged()
                i1++
                /* val adapter=myAdapter(this,listData)
                    listview1.adapter=adapter */
            }

        }

        //點擊某個item時
        main_listview.setOnItemClickListener{adapterView,view,i,l->
            val msg=adapter.getItem(i) //取得此Item
            val alertbuilder= AlertDialog.Builder(this)
            alertbuilder.setMessage("確定使用?")
                .setPositiveButton ("Use"){dialog, which ->
                    listData.remove(msg) //從listData移除此Item的資料
                    adapter.notifyDataSetChanged()
                }.setNegativeButton("Cancel") { dialog, which ->
                }.show()
            gv.setredcount()
        }

    }

    class myAdapter(private var activity: Activity, private var items: List<List<String>>): BaseAdapter(){
        private class ViewHolder(view: View?) {
            var name: TextView? = null
            var profile: ImageView?=null

            init {
                this.name = view?.findViewById(R.id.name)
                this.profile=view?.findViewById(R.id.profile)
            }
        }

        @SuppressLint("InflateParams")
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {

            val view: View?
            val viewHolder: ViewHolder

            if (convertView == null) {
                val inflater = activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

                // 需要創建視圖 listviewstyle
                view = inflater.inflate(R.layout.listviewstyle, null)
                viewHolder = ViewHolder(view)
                view?.tag = viewHolder
            } else {
                view = convertView
                viewHolder = view.tag as ViewHolder
            }

            //將items中每筆資料中的profile, name 依序放入
            viewHolder.name?.text = items[position][1]
            viewHolder.profile?.setImageResource(items[position][0].toInt())

            return view as View
        }

        override fun getItem(position: Int): List<Any> {
            return items[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getCount(): Int {
            return items.size
        }
    }
//
//    var i1:Int=1
//    var i2:Int=2
//val gv: GlobalVariable = applicationContext as GlobalVariable
//    var count1 = gv.getcount()
//
//
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_my__coupon)
//
//
//
//        var mycoupon_back: Button?=null
//        mycoupon_back=findViewById(R.id.mycoupon_back)
//        mycoupon_back.setOnClickListener {
//            var intentP31= Intent(this, fittingroom ::class.java)
//            startActivityForResult(intentP31,31)
//        }
//
//
//        val listData= mutableListOf<List<String>>(listOf(R.drawable.coupon.toString(),"服飾全面85折"))
//        val adapter=myAdapter(this,listData)
//        listview1.adapter=adapter
//
//        set.setOnClickListener{
//            if (listview1.adapter !=null) {
//                while(i1<i2) {
//
//                    listData.add(listOf(R.drawable.coupon.toString(),"服飾全面85折"))
//
//                    val adapter=myAdapter(this,listData)
//                    listview1.adapter=adapter
//                    adapter.notifyDataSetChanged()
//
//                    i1++
//                }
//            }
//
//
//        }
//
//        listview1.setOnItemClickListener{adapterView,view,i,l->
//            //val alertbuilder= AlertDialog.Builder(this)
//           // val msg=adapter.getItem(i)
//            /*alertbuilder.setMessage("確定使用?")
//                .setPositiveButton ("Use"){dialog, which ->
//                    listData.remove(msg)//從listData移除此Item的資料
//                    adapter.notifyDataSetChanged()
//
//
//                }.setNegativeButton("Cancel") { dialog, which ->
//                }.show()
//
//             */
//
//            val msg=adapter.getItem(i) //取得此Item
//            val alertbuilder= AlertDialog.Builder(this)
//            alertbuilder.setMessage("確定刪除?")
//                .setPositiveButton ("Delete"){dialog, which ->
//                    listData.remove(msg) //從listData移除此Item的資料
//                    adapter.notifyDataSetChanged()
//                }.setNegativeButton("Cancel") { dialog, which ->
//                }.show()
//           // i1 -= 1
//           // count1-=1
//           // gv.setredcount()
//
//
//        }
//    }
//
//    class myAdapter(private var activity: Activity, private var items: List<List<String>>): BaseAdapter(){
//        private class ViewHolder(view: View?) {
//            var name: TextView? = null
//            var profile: ImageView?=null
//
//            init {
//                this.name = view?.findViewById(R.id.name)
//                this.profile=view?.findViewById(R.id.profile)
//            }
//        }
//
//        @SuppressLint("InflateParams")
//        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
//
//            val view: View?
//            val viewHolder: ViewHolder
//
//            if (convertView == null) {
//                val inflater = activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
//
//                // 需要創建視圖 listviewstyle
//                view = inflater.inflate(R.layout.listviewstyle, null)
//                viewHolder = ViewHolder(view)
//                view?.tag = viewHolder
//            } else {
//                view = convertView
//                viewHolder = view.tag as ViewHolder
//            }
//
//            //將items中每筆資料中的profile, name 依序放入
//            viewHolder.name?.text = items[position][1]
//            viewHolder.profile?.setImageResource(items[position][0].toInt())
//
//            return view as View
//        }
//
//        override fun getItem(position: Int): List<Any> {
//            return items[position]
//        }
//
//        override fun getItemId(position: Int): Long {
//            return position.toLong()
//        }
//
//        override fun getCount(): Int {
//            return items.size
//        }
//    }
}