package com.example.fittingroom

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class Coupon : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_coupon)
        val gv: GlobalVariable = applicationContext as GlobalVariable
        var mLotteryView: LotteryView? = null
        var mStart: ImageView?=null
        var answer:TextView?=null
        mLotteryView = findViewById(R.id.lottery)
        mStart = findViewById(R.id.node)
        mStart.setOnClickListener(View.OnClickListener {
            mLotteryView.start()
            gv.setcount()
        })

        var coupon_back: Button?=null
        coupon_back=findViewById(R.id.coupon_back)

        coupon_back.setOnClickListener {
            var intentP14= Intent(this, fittingroom ::class.java)
            startActivityForResult(intentP14,14)
        }
    }
}
