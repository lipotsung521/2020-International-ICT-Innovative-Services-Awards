package com.example.fittingroom

import android.annotation.SuppressLint
import android.app.Activity
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.nfc.NfcAdapter
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlinx.android.synthetic.main.activity_cloth.*

class shopping : AppCompatActivity() {
    private var nfcAdapter: NfcAdapter? = null
    private var mPendingIntent: PendingIntent? = null

    var adapter: myAdapter?=null
    val listData= mutableListOf<List<String>>(listOf(R.drawable.fredlongskirt.toString(),"下身", "女 紅色 長裙","1"),listOf(R.drawable.fblackvup.toString(),"上身", "女 黑色 v領上衣","2"),listOf(R.drawable.fblackskirt.toString(),"下身", "女 黑色 短裙","3"),listOf(R.drawable.fwhiteshort.toString(),"下身", "女 白色 短褲","4"))
    val filterNames= mutableListOf<List<String>>(listOf(R.drawable.fredlongskirt.toString(),"下身", "女 紅色 長裙","1"),listOf(R.drawable.fblackvup.toString(),"上身", "女 黑色 v領上衣","2"),listOf(R.drawable.fblackskirt.toString(),"下身", "女 黑色 短裙","3"),listOf(R.drawable.fwhiteshort.toString(),"下身", "女 白色 短褲","4"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cloth)
        //add cloth.

        val gv: GlobalVariable = applicationContext as GlobalVariable
        val a:Int=gv.getshirt()
        val b:Int=gv.getshort()


        //***************NFC******************
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter == null) {
            //nfc not support your device.
            finish()
        }
        mPendingIntent = PendingIntent.getActivity(this, 0,
            Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0)


        //list裡面有頭像圖片、名字、訊息、分辨是否為自己送出的訊息
        //val listData=mutableListOf<List<String>>(listOf(R.drawable.monster01.toString(),"下身", "女 駝色 長褲"),listOf(R.drawable.monster07.toString(),"上衣", "女 駝色 長褲"))
//        val gv: GlobalVariable = applicationContext as GlobalVariable
        var bbb = findViewById<Button>(R.id.bt)

        adapter=myAdapter(this,filterNames)

        main_listview.adapter=adapter



        bbb.setOnClickListener()
        {
            var intentP2 = Intent(this, fittingroom::class.java)
            startActivityForResult(intentP2, 2)
        }


        //點擊某個item時
        main_listview.setOnItemClickListener{adapterView,view,i,l->
            //val msg=adapter.getItem(i) //取得此Item
            if(filterNames[i][3]=="1") {
                gv.setshirt(11)
                Toast.makeText(this, "您選擇紅色典雅長裙", Toast.LENGTH_LONG).show()
            }
            if(filterNames[i][3]=="2") {
                gv.setshort(21)
                Toast.makeText(this, "您選擇黑色v領上衣", Toast.LENGTH_LONG).show()
            }
            if(filterNames[i][3]=="3") {
                gv.setshirt(12)
                Toast.makeText(this, "您選擇黑色短裙", Toast.LENGTH_LONG).show()
            }
            if(filterNames[i][3]=="4") {
                gv.setshirt(13)
                Toast.makeText(this, "您選擇白色短褲", Toast.LENGTH_LONG).show()
            }



        }

        var Searchtext = findViewById(R.id.search_input) as EditText
        Searchtext.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {}

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {}

            override fun afterTextChanged(editable: Editable) {
                //this@MainActivity.filterQuery(editable.toString())
                filterQuery(editable.toString())
            }
        })
    }
    //***********NFC*********
    override fun onResume() {
        super.onResume()
        nfcAdapter?.enableForegroundDispatch(this,mPendingIntent, null, null)
    }
    override fun onPause() {
        super.onPause()
        nfcAdapter?.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val cardID = ByteArrayToHexString(intent.getByteArrayExtra(NfcAdapter.EXTRA_ID))
        Toast.makeText(this, "你是$cardID", Toast.LENGTH_SHORT).show()

        //753F3266//55E06A3D//B5751B3965//6549FC3F//C5577866
        //F5728A3D//F5394F32
        val gv: GlobalVariable = applicationContext as GlobalVariable
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (vibrator.hasVibrator()) { // Vibrator availability checking
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(
                    VibrationEffect.createOneShot(
                        500,
                        VibrationEffect.DEFAULT_AMPLITUDE
                    )
                ) // New vibrate method for API Level 26 or higher
            } else {
                vibrator.vibrate(500) // Vibrate method for below API Level 26
            }
        }
        if(cardID=="C5577866")
        {
            listData.add(listOf(R.drawable.videoshirt.toString(),"上身", "女 機能防潑水會呼吸的衝鋒衣","3"))
            filterNames.add(listOf(R.drawable.videoshirt.toString(),"上身", "女 機能防潑水會呼吸的衝鋒衣","3"))
            adapter!!.notifyDataSetChanged()
        }
        if(cardID=="F5728A3D")
        {
            gv.setshirt(11)
            Toast.makeText(this, "您選擇紅色典雅長裙", Toast.LENGTH_LONG).show()
        }
        if(cardID=="F5394F32")
        {
            gv.setshirt(13)
            Toast.makeText(this, "您選擇白色短褲", Toast.LENGTH_LONG).show()
        }
    }

    private fun ByteArrayToHexString(inarray: ByteArray?): String { //把byteArray換成16進位的String
        var i: Int
        var j: Int
        var `in`: Int
        val hex = arrayOf("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F")//對照表
        var out = ""
        j = 0
        while (j < inarray!!.size) {
            `in` = inarray[j].toInt() and 0xff
            i = `in` shr 4 and 0x0f //往右邊shift四次，跑到右邊
            out += hex[i] //前面轉成16進位的結果
            i = `in` and 0x0f
            out += hex[i]
            ++j
        }
        return out
    }


    class myAdapter(private var activity: Activity, private var items: List<List<String>>): BaseAdapter(){
        private class ViewHolder(view: View?) {
            var name: TextView? = null
            var profile: ImageView?=null
            var message: TextView? = null
            init {
                this.name = view?.findViewById(R.id.textview)
                this.profile=view?.findViewById(R.id.image_app)
                this.message=view?.findViewById(R.id.textview2)

            }
        }
        @SuppressLint("InflateParams")
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {

            val view: View?
            val viewHolder: ViewHolder

            if (convertView == null) {
                val inflater = activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
                // 需要創建視圖 listviewstyle
                view = inflater.inflate(R.layout.listviewstyle2, null)
                viewHolder = ViewHolder(view)
                view?.tag = viewHolder
            } else {
                view = convertView
                viewHolder = view.tag as ViewHolder
            }
            //將items中每筆資料中的profile, name 依序放入
            viewHolder.name?.text = items[position][1]
            viewHolder.profile?.setImageResource(items[position][0].toInt())
            viewHolder.message?.text=items[position][2]
            return view as View
        }

        override fun getItem(position: Int): List<Any> {
            return items[position]
        }

        override fun getItemId(position: Int): Long {
            return position.toLong()
        }

        override fun getCount(): Int {
            return items.size
        }
    }

    /* access modifiers changed from: private */
    fun filterQuery(text: String){
        filterNames.clear()
        for (s in 0 until listData.size){
            if (listData[s][1].toLowerCase().contains(text)||listData[s][2].toLowerCase().contains(text)){
                filterNames.add(listData[s])
                adapter?.notifyDataSetChanged();
            }
        }

    }}