package com.example.fittingroom

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class Magazine : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_magazine)

        val bt1: Button = findViewById(R.id.bt1)
        bt1.setOnClickListener {
            val bt1uri = Uri.parse("https://www.life8.com.tw/Shop/itemDetail.aspx?mNo1=11162&cno=16926&kw=%e8%a5%bf%e8%a3%9d&m=1&p=532")
            val bt1intent = Intent(Intent.ACTION_VIEW, bt1uri)
            startActivity(bt1intent)}

        val bt4: Button = findViewById(R.id.bt4)
        bt4.setOnClickListener {
            val bt4uri = Uri.parse("https://www.life8.com.tw/Shop/itemDetail.aspx?mNo1=10235&cno=18611&AdSource=AD12&m=19&p=1497")
            val bt4intent = Intent(Intent.ACTION_VIEW, bt4uri)
            startActivity(bt4intent)}

        val bt5: Button = findViewById(R.id.bt5)
        bt5.setOnClickListener {
            val bt5uri = Uri.parse("https://www.life8.com.tw/Shop/itemDetail.aspx?mNo1=10308&cno=19229&AdSource=AD12&m=19&p=1497")
            val bt5intent = Intent(Intent.ACTION_VIEW, bt5uri)
            startActivity(bt5intent)}

        val bt7: Button = findViewById(R.id.bt7)
        bt7.setOnClickListener {
            val bt7uri = Uri.parse("https://www.life8.com.tw/Shop/itemDetail.aspx?mNo1=06508&cno=18399&AdSource=AD12&m=19&p=1497")
            val bt7intent = Intent(Intent.ACTION_VIEW, bt7uri)
            startActivity(bt7intent)}

        val bt6: Button = findViewById(R.id.bt6)
        bt6.setOnClickListener {
            val bt6uri = Uri.parse("https://www.life8.com.tw/Shop/itemList.aspx?m=3&p=146")
            val bt6intent = Intent(Intent.ACTION_VIEW, bt6uri)
            startActivity(bt6intent)}

        val bt3: Button = findViewById(R.id.bt3)
        bt3.setOnClickListener {
            val bt3uri = Uri.parse("https://www.life8.com.tw/Shop/itemDetail.aspx?mNo1=10288&cno=19155&m=1&p=217")
            val bt3intent = Intent(Intent.ACTION_VIEW, bt3uri)
            startActivity(bt3intent)}

        val bt2: Button = findViewById(R.id.bt2)
        bt2.setOnClickListener {
            val bt2uri = Uri.parse("https://www.life8.com.tw/Shop/itemDetail.aspx?mNo1=02559&cno=19223&m=1&p=111")
            val bt2intent = Intent(Intent.ACTION_VIEW, bt2uri)
            startActivity(bt2intent)
        }
    }
}
