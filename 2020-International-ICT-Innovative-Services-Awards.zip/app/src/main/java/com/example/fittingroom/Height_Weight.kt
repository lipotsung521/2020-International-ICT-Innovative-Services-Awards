package com.example.fittingroom

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.WindowManager
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_height__weight.*

class Height_Weight : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.activity_height__weight)

        val gv: GlobalVariable = applicationContext as GlobalVariable
        val enter: Button =findViewById(R.id.p2_enter)
        val height: EditText =findViewById(R.id.p2_height)
        val weight: EditText =findViewById(R.id.p2_weight)
        val he:TextView=findViewById(R.id.textView2)
        val we:TextView=findViewById(R.id.textView3)
        val w: ImageView =findViewById(R.id.imageView1)
        val h: ImageView=findViewById(R.id.imageView3)

        var Height=height.getText().toString()
        var Weight=weight.getText().toString()

        gv?.setHeight(Height)
        gv?.setWeight(Weight)

        val top_animation = AnimationUtils.loadAnimation(this, R.anim.top_animation)
        val botton_animation = AnimationUtils.loadAnimation(this, R.anim.botton_animation)

        enter.setAnimation(botton_animation)
        height.setAnimation(top_animation)
        weight.setAnimation(top_animation)
        he.setAnimation(top_animation)
        we.setAnimation(top_animation)
        h.setAnimation(top_animation)
        w.setAnimation(top_animation)

        enter.setOnClickListener {
            var intentP2= Intent(this, fittingroom::class.java)
            startActivityForResult(intentP2,2)
    }
}}
