package com.example.fittingroom

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_cloth.*
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.activity_main)


        var start : Button? =null

        start=findViewById(R.id.p1_start)

        start?.setOnClickListener {
            var intentP1= Intent(this, Height_Weight ::class.java)
            startActivityForResult(intentP1,1)

            val top_animation = AnimationUtils.loadAnimation(this, R.anim.top_animation)
            val botton_animation = AnimationUtils.loadAnimation(this, R.anim.botton_animation)
        }
    }
}
