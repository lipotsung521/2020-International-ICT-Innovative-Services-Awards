package com.example.fittingroom

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.app.ActivityCompat.startActivityForResult
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.ml.vision.label.FirebaseVisionImageLabel
import com.google.firebase.ml.vision.label.FirebaseVisionImageLabeler
import kotlinx.android.synthetic.main.item_row.view.*


class ImageLabelAdapter(private var firebaseVisionList: List<Any>) : RecyclerView.Adapter<ImageLabelAdapter.ItemHolder>() {
    lateinit var context: Context




        inner class ItemHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {



        fun bindCloud(currentItem: FirebaseVisionImageLabel) {
            when {
                currentItem.confidence > .70 -> itemView.itemAccuracy.setTextColor(ContextCompat.getColor(context, R.color.green))
                currentItem.confidence < .30 -> itemView.itemAccuracy.setTextColor(ContextCompat.getColor(context, R.color.red))
                else -> itemView.itemAccuracy.setTextColor(ContextCompat.getColor(context, R.color.orange))
            }
            itemView.itemName.text = currentItem.text
            itemView.itemAccuracy.text = "Probability : ${(currentItem.confidence * 100).toInt()}%"

        }

        fun bindDevice(currentItem: FirebaseVisionImageLabel) {
            when {
                currentItem.confidence > .70 -> itemView.itemAccuracy.setTextColor(ContextCompat.getColor(context, R.color.green))
                currentItem.confidence < .30 -> itemView.itemAccuracy.setTextColor(ContextCompat.getColor(context, R.color.red))
                else -> itemView.itemAccuracy.setTextColor(ContextCompat.getColor(context, R.color.orange))
            }

            itemView.itemName.text = currentItem.text
            itemView.itemAccuracy.text = "Probability : ${(currentItem.confidence * 100).toInt()}%"


        }

    }



    fun setList(visionList: List<Any>) {
        firebaseVisionList = visionList
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: ItemHolder, position: Int) {
        val currentItem = firebaseVisionList[position]
        if (currentItem is FirebaseVisionImageLabel)
        {
            holder.bindCloud(currentItem) }
        else
            holder.bindDevice(currentItem as FirebaseVisionImageLabel)
        holder.itemView.setOnClickListener {
            view:View?->Unit
            val context=holder.itemView.context
            if(holder.itemView.itemName.text=="Jacket"){
                val intent=Intent(context,Outerwear::class.java)
                context.startActivity(intent)
            }
            else if(holder.itemView.itemName.text=="Cloth"){
                val uri: Uri = Uri.parse("https://www.nike.com/tw/t/dri-fit-my-life-%E7%94%B7%E6%AC%BE%E7%B1%83%E7%90%83-t-%E6%81%A4-jmJhXp")
                val intent = Intent(Intent.ACTION_VIEW, uri)
                context.startActivity(intent)
            }
            else if(holder.itemView.itemName.text=="Chair"){
                val uri: Uri = Uri.parse("https://www.nike.com/tw/t/dri-fit-my-life-%E7%94%B7%E6%AC%BE%E7%B1%83%E7%90%83-t-%E6%81%A4-jmJhXp")
                val intent = Intent(Intent.ACTION_VIEW, uri)
                context.startActivity(intent)
            }
            else if(holder.itemView.itemName.text=="Outerwear"){
                val intent=Intent(context,Outerwear::class.java)
                context.startActivity(intent)
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemHolder {
        context = parent.context
        return ItemHolder(LayoutInflater.from(context).inflate(R.layout.item_row, parent, false))
    }

    override fun getItemCount() = firebaseVisionList.size
}