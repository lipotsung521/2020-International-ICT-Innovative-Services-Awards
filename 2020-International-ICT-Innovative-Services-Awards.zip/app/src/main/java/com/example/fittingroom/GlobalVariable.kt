package com.example.fittingroom

import android.app.Application

public class GlobalVariable: Application() {
    private var count = 0
    private var Height=""
    private var Weight=""
    private var size=1


    fun setcount() {
        this.count += 1
    }
    fun setredcount(){
        this.count-=1
    }

    fun setHeight(item: String) {
        this.Height = item
    }

    fun setWeight(item: String) {
        this.Weight=item
    }

    fun setaddsize(){
        this.size+=1
    }
    fun setredsize(){
        this.size-=1
    }

    fun getcount(): Int {
        return count
    }
    fun getHeight(): String {
        return Height
    }
    fun getWeight(): String{
        return Weight
    }
    fun getsize():Int{
        return size
    }

    //**cloth**
    private var shirt= 0
    private var short = 0

    fun setshirt(item: Int) {
        this.shirt=item
    }
    fun setshort(item: Int) {
        this.short=item
    }

    fun getshirt(): Int {
        return shirt
    }
    fun getshort(): Int {
        return short
    }
}