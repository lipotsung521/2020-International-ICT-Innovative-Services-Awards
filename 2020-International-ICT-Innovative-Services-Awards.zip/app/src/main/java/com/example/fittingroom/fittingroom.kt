package com.example.fittingroom

import android.Manifest
import android.app.*
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.AsyncTask
import android.os.Build
import android.os.Bundle
import android.os.Vibrator
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.android.synthetic.main.activity_fittingroom.*
import org.json.JSONObject
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.pow
import kotlin.math.sqrt

//******搖一搖宣告******
private lateinit var sm: SensorManager
private lateinit var mAccelerometer: Sensor

private val SPEED_THRESHOLD = 1000//搖動速度閥值
private var UPDATE_TIME_INTERVAL = 200//達成觸發條件之搖動持續時間
private var mLastX = 0F//一開始的X方向加速度
private var mLastY = 0F//一開始的Y方向加速度
private var mLastZ = 0F//一開始的Z方向加速度
private var mSpeed = 0F//三軸加速度加權之搖動速度
private var mLastUpdateTime:Long = 0//一開始的時間
private lateinit var Speed: TextView
private lateinit var State: TextView

class fittingroom : AppCompatActivity() {
    //****天氣****
    val CITY: String = "taipei"
    val API: String = "59c7b1780ac88e23dd2d1a7a2086d72c"
    //****衣服宣告****
    private var fruitNo = 0
    private var fruitNo2 = 0
    var image: ImageView? = null
    var image2: ImageView? = null


    var button01: Button? = null

    var fruit: ArrayList<String>? = null
    var fruit2: ArrayList<String>? = null
    //*******Beacon**********
    private var BT_Search: Button? = null
    private var TV1: TextView? = null
    private var mBluetoothAdapter: BluetoothAdapter? = null
    private val bluetoothdeviceslist = ArrayList<String>()
    internal var dis: Double = 0.toDouble()
    companion object {
        private val PERMISSION_REQUEST_COARSE_LOCATION = 1
    }

    private val myreceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val action = intent.action
            if (BluetoothDevice.ACTION_FOUND == action) {
                val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                val rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, java.lang.Short.MIN_VALUE).toInt()
                val txPower = -59.0
                val ratio = rssi * 1.0 / txPower
                if (ratio < 1.0) {
                    dis = Math.pow(ratio, 10.0)
                } else {
                    dis = 0.89976 * Math.pow(ratio, 7.7095) + 0.111
                }
                try {

                    TV1!!.text = device!!.name.toString() + "         " + java.lang.Double.toString(dis)


                        if(device.name=="BR517486"&& dis<10)
                        {
                        val channelId = "My_Channel_ID"
                        createNotificationChannel(channelId)
                        val uri: Uri = Uri.parse("https://reurl.cc/yZVyX2")
                        val intent = Intent(Intent.ACTION_VIEW, uri)
                        intent.apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK

                        }


                        val pendingIntent = PendingIntent.getActivity(this@fittingroom,0,intent,0)
                        val buttonIntent = Intent(this@fittingroom,MyBroadcastReceiver::class.java)
                        buttonIntent.apply {
                            // action("Do Pending Task")
                            putExtra("My Favorite Color","RED Color")
                        }

                        val buttonPendingIntent = PendingIntent.getBroadcast(this@fittingroom,0,buttonIntent,0)


                        //  btn.setOnClickListener{
                        val notificationBuilder = NotificationCompat.Builder(this@fittingroom,channelId)
                            .setSmallIcon(R.drawable.crayon)
                            .setContentTitle("今日店內推薦穿搭")
                            //.setContentText("")
                            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                            .setContentIntent(pendingIntent)
                            .addAction(R.drawable.crayon,"Do Task",buttonPendingIntent)

                        with(NotificationManagerCompat.from(this@fittingroom)){
                            notify(1, notificationBuilder.build())
                        }

                        // }
                    }
                    if(device.name=="BR517487"&& dis<10)
                    {
                        val channelId = "My_Channel_ID"
                        createNotificationChannel(channelId)
                        val uri: Uri = Uri.parse("https://reurl.cc/GV0VZW")
                        val intent = Intent(Intent.ACTION_VIEW, uri)
                        intent.apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK

                        }


                        val pendingIntent = PendingIntent.getActivity(this@fittingroom,0,intent,0)
                        val buttonIntent = Intent(this@fittingroom,MyBroadcastReceiver::class.java)
                        buttonIntent.apply {
                            // action("Do Pending Task")
                            putExtra("My Favorite Color","RED Color")
                        }

                        val buttonPendingIntent = PendingIntent.getBroadcast(this@fittingroom,0,buttonIntent,0)


                        //  btn.setOnClickListener{
                        val notificationBuilder = NotificationCompat.Builder(this@fittingroom,channelId)
                            .setSmallIcon(R.drawable.crayon)
                            .setContentTitle("慶祝父親節")
                            .setContentText("今日本店商品一律88折")
                            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                            .setContentIntent(pendingIntent)
                            .addAction(R.drawable.crayon,"Do Task",buttonPendingIntent)

                        with(NotificationManagerCompat.from(this@fittingroom)){
                            notify(1, notificationBuilder.build())
                        }

                    }
                    if(device!!.name=="BR517488"&& dis<10)
                    {

                        val channelId = "My_Channel_ID"
                        createNotificationChannel(channelId)
                        val uri: Uri = Uri.parse("https://reurl.cc/g75znz")
                        val intent = Intent(Intent.ACTION_VIEW, uri)
                        intent.apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK

                        }


                        val pendingIntent = PendingIntent.getActivity(this@fittingroom,0,intent,0)
                        val buttonIntent = Intent(this@fittingroom,MyBroadcastReceiver::class.java)
                        buttonIntent.apply {
                            // action("Do Pending Task")
                            putExtra("My Favorite Color","RED Color")
                        }

                        val buttonPendingIntent = PendingIntent.getBroadcast(this@fittingroom,0,buttonIntent,0)


                        //btn.setOnClickListener{
                        val notificationBuilder = NotificationCompat.Builder(this@fittingroom,channelId)
                            .setSmallIcon(R.drawable.crayon)
                            .setContentTitle("明星同款熱銷商品")
                            .setContentText("想要get明星同款嗎?")
                            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                            .setContentIntent(pendingIntent)
                            .addAction(R.drawable.crayon,"Do Task",buttonPendingIntent)

                        with(NotificationManagerCompat.from(this@fittingroom)){
                            notify(1, notificationBuilder.build())
                        }
                    }




                } catch (e: Exception) {

                }

            }

        }

    }
    private fun createNotificationChannel(channelId:String) {
        // Create the NotificationChannel, but only on API 26+ (Android 8.0) because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val name = "My Channel"
            val channelDescription = "Channel Description"
            val importance = NotificationManager.IMPORTANCE_DEFAULT

            val channel = NotificationChannel(channelId,name,importance)
            channel.apply {
                description = channelDescription
            }

            // Finally register the channel with system
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
    //*********************
    //**************coupon qrcode
    private var scan = View.OnClickListener {
        val intent = Intent("com.google.zxing.client.android.SCAN")  // 連結ZXING的API，開啟條碼掃描器
        intent.putExtra("SCAN_MODE", "SCAN_MODE")     // 設定參數，兩種條碼都讀
        startActivityForResult(intent, 33)        //因為要回傳掃描結果所以要使用startActivityForResult
        // 要求回傳1
    }
    //*********************
    //***************service qrcode
    //**********************


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.activity_fittingroom)
        //*********搖一搖***********
        sm = getSystemService(SENSOR_SERVICE) as SensorManager
        //透過Sensormanager選取預設的加速度sensor
        mAccelerometer = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        //註冊Listener(參數一:sensorEventListener,參數二:指定的sensor,參數三:設定事件發生後傳送數值的頻率)
        sm.registerListener(myAccelerometerListener, mAccelerometer, SensorManager.SENSOR_DELAY_GAME)
        Speed = findViewById(R.id.speed_show)
        State = findViewById(R.id.state_show)

        //******天氣************
        weatherTask().execute()



        val gv: GlobalVariable = applicationContext as GlobalVariable
        val a:Int=gv.getshirt()
        val b:Int=gv.getshort()

        //********換圖片************************************
        //將題目加入List
        fruit = ArrayList()
        if(a==11)
        {fruit!!.add("fredlongskirt")}
        if(a==12)
        {fruit!!.add("fblackskirt")}
        if(a==13)
        {fruit!!.add("fwhiteshort")}
        fruit!!.add("fpinkskirt")
        fruit!!.add("fblackjean")
        fruit!!.add("fredlongskirt")
        fruit!!.add("fblackskirt")
        fruit!!.add("fjeanshorts")
        fruit!!.add("fblackfloraskirt")
        fruit!!.add("fcamelskirt")
        fruit!!.add("fflorashkirt")
        fruit!!.add("fflorashorts")
        fruit!!.add("fjeanskirt")
        fruit!!.add("flongjeans")
        fruit!!.add("fpinkskirt")
        fruit!!.add("fpinksporty")
        fruit!!.add("fwhitelow")
        fruit!!.add("fwhiteshort")
        fruit!!.add("fwhiteskirt")



        fruit2 = ArrayList()
        if(b==21)
        {fruit2!!.add("fblackvup")}
        fruit2!!.add("fflorashirt")
        fruit2!!.add("fpurpleup")
        fruit2!!.add("fpinkshirt")
        fruit2!!.add("fblackup")
        fruit2!!.add("fpinkshirt")
//        fruit2!!.add("fcamelup")
//        fruit2!!.add("ffloraup")
        fruit2!!.add("fgreenfloraup")
        fruit2!!.add("fpinkfloraup")
        fruit2!!.add("fpinkshirt")
//        fruit2!!.add("fpinkup")
        fruit2!!.add("fpurpleup")
        fruit2!!.add("fpurpleup2")
        fruit2!!.add("fwhitevup")
        fruit2!!.add("fyellow")
        GetFirstFruit() //顯示圖片
        GetFirstFruit2() //顯示圖片

        button01 = findViewById<View>(R.id.button) as Button
        button01!!.setOnClickListener(ButtonOnClick)

        //Toast.makeText(this,a.toString(), Toast.LENGTH_LONG).show()


        var ar:Button? =null
        var add : Button? =null
        var cloth : Button? =null
        var share : Button? =null
        var service : Button? =null
        var beacon:Button?=null
        var coupon : Button? =null
        var my_coupon : Button? =null
        var magazine : Button? =null
        var lens : Button? =null
        var reset : Button? =null
        var buy:FloatingActionButton?=null

        ar=findViewById(R.id.ar)
        add=findViewById(R.id.add)
        cloth=findViewById(R.id.cloth)
        share=findViewById(R.id.share)
        service=findViewById(R.id.service)
        coupon=findViewById(R.id.coupon)
        my_coupon=findViewById(R.id.my_coupon)
        magazine=findViewById(R.id.magazine)
        lens=findViewById(R.id.lens)
        reset=findViewById(R.id.reset)
        buy =findViewById(R.id.buy)
        val h=gv.getHeight()
        val w=gv.getWeight()
     //   val size:Int=gv.getsize()


        shop?.setOnClickListener {
            var intentP91= Intent(this, shopping::class.java)
            startActivityForResult(intentP91,91)
        }

        beacon_button?.setOnClickListener{

            val channelId = "My_Channel_ID"
            createNotificationChannel(channelId)
            val uri: Uri = Uri.parse("https://reurl.cc/g75znz")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK

            }


            val pendingIntent = PendingIntent.getActivity(this@fittingroom,0,intent,0)
            val buttonIntent = Intent(this@fittingroom,MyBroadcastReceiver::class.java)
            buttonIntent.apply {
                // action("Do Pending Task")
                putExtra("My Favorite Color","RED Color")
            }

            val buttonPendingIntent = PendingIntent.getBroadcast(this@fittingroom,0,buttonIntent,0)


            //btn.setOnClickListener{
            val notificationBuilder = NotificationCompat.Builder(this@fittingroom,channelId)
                .setSmallIcon(R.drawable.seulgibeautiful)
                .setContentTitle("明星同款熱銷商品")
                .setContentText("想要get明星同款嗎?")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .addAction(R.drawable.seulgibeautiful,"點擊了解更多",buttonPendingIntent)

            with(NotificationManagerCompat.from(this@fittingroom)){
                notify(1, notificationBuilder.build())
            }
        }

        buy?.setOnClickListener{
            val alertbuilder= AlertDialog.Builder(this)
            alertbuilder.setMessage("根據您輸入的身高/體重\n黑色v領上衣\n您適合的尺寸可能為S")
                .setNegativeButton ("BUY"){dialog, which ->
                    Toast.makeText(this,"謝謝您購買黑色v領上衣",Toast.LENGTH_LONG).show()

                }.setPositiveButton("CANCEL") { dialog, which ->
                }.show()
        }


        ar.setOnClickListener {
            var intent: Intent? = getPackageManager().getLaunchIntentForPackage("com.lipotsung.test")
            startActivity(intent)
//            var intentP17= Intent(this, AR ::class.java)
//            startActivityForResult(intentP17,17)
        }


        add?.setOnClickListener {
            var intentP3= Intent(this, Add_cloth ::class.java)
            startActivityForResult(intentP3,3)
        }

       cloth?.setOnClickListener {
        var intentP4= Intent(this, Cloth::class.java)
        startActivityForResult(intentP4,4)
       }

        share?.setOnClickListener {
            var intentP5= Intent(this, instagram ::class.java)
            startActivityForResult(intentP5,5)
        }


//        service?.setOnClickListener {
//            var intentP7= Intent(this, Service ::class.java)
//            startActivityForResult(intentP7,7)
//        }

        service?.setOnClickListener(scan)


        coupon.setOnClickListener(scan)

//        coupon?.setOnClickListener {
//            var intentP8= Intent(this, Coupon_qrcode::class.java)
//            startActivityForResult(intentP8,8)
//        }

        my_coupon?.setOnClickListener {
            var intentP30= Intent(this, My_Coupon::class.java)
            startActivityForResult(intentP30,30)
        }

        magazine?.setOnClickListener {
            var intentP9= Intent(this, Magazine ::class.java)
            startActivityForResult(intentP9,9)
        }

        lens?.setOnClickListener {
            var intentP21= Intent(this, ImageLabelActivity::class.java)
            startActivityForResult(intentP21,21)
        }
        reset?.setOnClickListener {
            var intentP10= Intent(this, Height_Weight ::class.java)
            startActivityForResult(intentP10,10)
        }
//******Beacon*************
        //BT_Search = findViewById<View>(R.id.beacon_button) as Button
        //TV1 = findViewById<View>(R.id.beacon_textView) as TextView
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        checkBluetoothPermission()
        SearchBluetooth()
        //BT_Search!!.setOnClickListener {
            if (mBluetoothAdapter!!.isDiscovering) {
                mBluetoothAdapter!!.cancelDiscovery()
            }
            mBluetoothAdapter!!.startDiscovery()
       // }
        //**********************
    }
    //****************Beacon*********
    private fun checkBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), PERMISSION_REQUEST_COARSE_LOCATION)
            }
        }
    }

    fun SearchBluetooth() {
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, "not find the bluetooth", Toast.LENGTH_SHORT).show()
            finish()
        }

        if (!mBluetoothAdapter!!.isEnabled) {
            val intent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivityForResult(intent, 1)
            val myDevices = mBluetoothAdapter!!.bondedDevices
            if (myDevices.size > 0) {
                for (device in myDevices)
                    bluetoothdeviceslist.add(device.name + ":" + device.address + "\n")
            }
        }
        var filter = IntentFilter(BluetoothDevice.ACTION_FOUND)
        registerReceiver(myreceiver, filter)
        filter = IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        registerReceiver(myreceiver, filter)
    }

    //*********Coupon qrcode

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    super.onActivityResult(requestCode, resultCode, data)

    if (requestCode == 33) {  //成功回傳值
        //requestCode在startActivityForResult傳入參數時決定的，如果成功的話會傳回相同的值
        if (resultCode == Activity.RESULT_OK) {
            val contents = data?.getStringExtra("SCAN_RESULT")  //ZXing回傳的內容

            when (contents) {
                "coupon" -> {
                    var intentP20 = Intent(this, Coupon::class.java)
                    startActivityForResult(intentP20, 20)
                    val uri =
                        Uri.parse("https://reurl.cc/Wdjx5D") //要跳轉的網址
                    val intent = Intent(Intent.ACTION_VIEW, uri)
                    startActivity(intent)
                }
                "https://line.me/ti/p/@153lhbpb" -> {
                    val uri:Uri = Uri.parse("https://line.me/ti/p/@153lhbpb");
                    val intent = Intent(Intent.ACTION_VIEW, uri);
                    startActivity(intent)
                }
            }
        }
    }
}
//*******************service qrcode
//**********搖一搖********
private val myAccelerometerListener = object: SensorEventListener {
    //sensor準確度發生變化的時候
    override fun onAccuracyChanged(p0: Sensor?, p1: Int) {}
    //sensor數值發生變化的時候
    override fun onSensorChanged(event: SensorEvent?) {
        if(event != null){
            var mCurrentUpdateTime = System.currentTimeMillis()//取得現在時間
            var mTimeInterval = mCurrentUpdateTime- mLastUpdateTime//計算時間差
            if (mTimeInterval<UPDATE_TIME_INTERVAL)//如果小於指定的時間區間則跳出函式
                return
            //計算目前加速度
            val xValue = event.values[0] // 加速度 - X 軸方向
            val yValue = event.values[1] // 加速度 - Y 軸方向
            val zValue = event.values[2] // 加速度 - Z 軸方向

            //甩動偏移速度 = xyz體感(Sensor)偏移 - 上次xyz體感(Sensor)偏移
            var DeltaX = xValue - mLastX
            var DeltaY = yValue - mLastY
            var DeltaZ = zValue - mLastZ
            //保存現在加速度及時間
            mLastX = xValue
            mLastY = yValue
            mLastZ = zValue
            mLastUpdateTime = mCurrentUpdateTime
            //速度加權計算公式
            mSpeed = sqrt(DeltaX.pow(2)+DeltaY.pow(2)+DeltaZ.pow(2)) * 10000/mTimeInterval
            //    UPDATE_TIME_INTERVAL=200
            //更改TextView中的內容
            var stop = 0
            if(mSpeed >SPEED_THRESHOLD && mTimeInterval>UPDATE_TIME_INTERVAL){

                stop = 1
                Speed.text = mSpeed.toString()
                State.text = "搖動中!!!"
                if (fruitNo >= fruit!!.size - 1) fruitNo = 0 //超過題目位址,回到初始值
                else fruitNo++
                if (fruitNo2 >= fruit2!!.size - 1) fruitNo2 = 0 //超過題目位址,回到初始值
                else fruitNo2++

                val gv: GlobalVariable = applicationContext as GlobalVariable
                gv.setshirt(0)
                gv.setshort(0)
                GetFirstFruit()
                GetFirstFruit2()

                val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
                vibrator.vibrate(300)//參數為震動持續時間
                UPDATE_TIME_INTERVAL=3000
            }

            else {
                State.text = "停止搖動..."
                UPDATE_TIME_INTERVAL=200
            }
        }
    }
}
    override fun onPause() {
        sm.unregisterListener(myAccelerometerListener)
        super.onPause()
    }
    //**********天氣************

    inner class weatherTask() : AsyncTask<String, Void, String>() {
        override fun onPreExecute() {
            super.onPreExecute()
            /* Showing the ProgressBar, Making the main design GONE */
            /*   findViewById<ProgressBar>(R.id.loader).visibility = View.VISIBLE
               findViewById<RelativeLayout>(R.id.mainContainer).visibility = View.GONE
               findViewById<TextView>(R.id.errorText).visibility = View.GONE

             */
        }

        override fun doInBackground(vararg params: String?): String? {
            var response:String?
            try{
                response = URL("https://api.openweathermap.org/data/2.5/weather?q=$CITY&units=metric&appid=$API").readText(
                    Charsets.UTF_8
                )
            }catch (e: Exception){
                response = null
            }
            return response
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            try {
                /* Extracting JSON returns from the API */
                val jsonObj = JSONObject(result)
                val main = jsonObj.getJSONObject("main")
                val sys = jsonObj.getJSONObject("sys")
                val wind = jsonObj.getJSONObject("wind")
                val weather = jsonObj.getJSONArray("weather").getJSONObject(0)

                val updatedAt:Long = jsonObj.getLong("dt")
                val updatedAtText = "Updated at: "+ SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.ENGLISH).format(
                    Date(updatedAt*1000)
                )
                val temp = main.getString("temp")+"°C"
                val tempMin = "Min Temp: " + main.getString("temp_min")+"°C"   //天氣數值
                val tempMax = "Max Temp: " + main.getString("temp_max")+"°C"
                val pressure = main.getString("pressure")
                val humidity = main.getString("humidity")

                val sunrise:Long = sys.getLong("sunrise")
                val sunset:Long = sys.getLong("sunset")
                val windSpeed = wind.getString("speed")
                val weatherDescription = weather.getString("description")

                val address = jsonObj.getString("name")+", "+sys.getString("country")
                var weather_iv:ImageView?=null
                weather_iv=findViewById(R.id.beacon_button)
                /* Populating extracted data into our views */
                findViewById<TextView>(R.id.temp).text = temp
                findViewById<TextView>(R.id.address).text = address
                findViewById<TextView>(R.id.updated_at).text =  updatedAtText
                findViewById<TextView>(R.id.status).text = weatherDescription.capitalize()
//                if(weatherDescription=="Scattered clouds"){
//                    weather_iv?.setImageResource(R.drawable.suncloud)
//                }
//                if(weatherDescription=="Sun"){
//                    weather_iv?.setImageResource(R.drawable.sun)
//                }
//                if(weatherDescription=="Clouds"){
//                    weather_iv?.setImageResource(R.drawable.cloud)
//                }
//                if(weatherDescription=="Wind"){
//                    weather_iv?.setImageResource(R.drawable.windy)
//                }
//                if(weatherDescription=="Thunderstorm"){
//                    weather_iv?.setImageResource(R.drawable.storm)
//                }
                /*   findViewById<TextView>(R.id.temp_min).text = tempMin
                   findViewById<TextView>(R.id.temp_max).text = tempMax
                   findViewById<TextView>(R.id.sunrise).text = SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(
                       Date(sunrise*1000)
                   )
                   findViewById<TextView>(R.id.sunset).text = SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(
                       Date(sunset*1000)
                   )
                   findViewById<TextView>(R.id.wind).text = windSpeed
                   findViewById<TextView>(R.id.pressure).text = pressure
                   findViewById<TextView>(R.id.humidity).text = humidity

                   /* Views populated, Hiding the loader, Showing the main design */
                   findViewById<ProgressBar>(R.id.loader).visibility = View.GONE
                   findViewById<RelativeLayout>(R.id.mainContainer).visibility = View.VISIBLE

                 */

            } catch (e: Exception) {
                //  findViewById<ProgressBar>(R.id.loader).visibility = View.GONE
                //  findViewById<TextView>(R.id.errorText).visibility = View.VISIBLE
            }


        }
    }


    //**************************換衣服**********************************************************
    private val ButtonOnClick: View.OnClickListener = object : View.OnClickListener {
        override fun onClick(v: View?) {
            if (fruitNo >= fruit!!.size - 1) fruitNo = 0 //超過題目位址,回到初始值
            else fruitNo++

            if (fruitNo2 >= fruit2!!.size - 1) fruitNo2 = 0 //超過題目位址,回到初始值
            else fruitNo2++

            val gv: GlobalVariable = applicationContext as GlobalVariable
            gv.setshirt(0)
            gv.setshort(0)
            GetFirstFruit()
            GetFirstFruit2()
        }
    }
    private fun GetFirstFruit() {
        image = findViewById<View>(R.id.imageView1) as ImageView
        var fruitarray = arrayOfNulls<String>(fruitNo) //喧告字串陣列大小
        fruitarray = fruit!!.toArray(fruitarray) //將List放到字串陣列裡來
        val uri = "@drawable/" + fruitarray[fruitNo].toString() //圖片路徑和名稱
        val imageResource = resources.getIdentifier(uri, null, packageName) //取得圖片Resource位子
        image!!.setImageResource(imageResource)
    }

    private fun GetFirstFruit2() {
        image2 = findViewById<View>(R.id.imageView2) as ImageView
        var fruitarray1 = arrayOfNulls<String>(fruitNo2) //喧告字串陣列大小
        fruitarray1 = fruit2!!.toArray(fruitarray1) //將List放到字串陣列裡來
        val uri = "@drawable/" + fruitarray1[fruitNo2].toString() //圖片路徑和名稱
        val imageResource = resources.getIdentifier(uri, null, packageName) //取得圖片Resource位子
        image2!!.setImageResource(imageResource)
    }
}



