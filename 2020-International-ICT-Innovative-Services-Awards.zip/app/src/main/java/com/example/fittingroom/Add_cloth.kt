package com.example.fittingroom

import android.app.Activity
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.nfc.NfcAdapter
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_add_cloth.*

class Add_cloth : AppCompatActivity() {
    private var nfcAdapter: NfcAdapter? = null
    private var mPendingIntent: PendingIntent? = null
    private val ACTION_CAMERA_REQUEST_CODE = 100
    private val ACTION_ALBUM_REQUEST_CODE = 200


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_cloth)
        //拍照
        val gv: GlobalVariable = applicationContext as GlobalVariable
        var b1 = findViewById<Button>(R.id.cameraAppButton)
        b1.setOnClickListener()
        {
            gv.setshirt(11)
        }

        cameraAppButton.setOnClickListener(cameraAppButtonHandler)
        albumAppButton.setOnClickListener(albumAppButtonHandler)

        imageView.scaleType = ImageView.ScaleType.CENTER_CROP

        //NFC
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        if (nfcAdapter == null) {
            //nfc not support your device.
            finish()
        }
        mPendingIntent = PendingIntent.getActivity(this, 0,
            Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0)



        var add_cloth_back:Button?=null
        add_cloth_back=findViewById(R.id.add_cloth_back)
        add_cloth_back.setOnClickListener {
                var intentP11= Intent(this, fittingroom ::class.java)
                startActivityForResult(intentP11,11)
        }

    }
    override fun onResume() {
        super.onResume()
        nfcAdapter?.enableForegroundDispatch(this,mPendingIntent, null, null)
    }
    override fun onPause() {
        super.onPause()
        nfcAdapter?.disableForegroundDispatch(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val cardID = ByteArrayToHexString(intent.getByteArrayExtra(NfcAdapter.EXTRA_ID))
        Toast.makeText(this, "你是$cardID", Toast.LENGTH_SHORT).show()

        //753F3266//55E06A3D//B5751B3965//6549FC3F//C5577866
        //F5728A3D//F5394F32
        val gv: GlobalVariable = applicationContext as GlobalVariable
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (vibrator.hasVibrator()) { // Vibrator availability checking
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(
                    VibrationEffect.createOneShot(
                        500,
                        VibrationEffect.DEFAULT_AMPLITUDE
                    )
                ) // New vibrate method for API Level 26 or higher
            } else {
                vibrator.vibrate(500) // Vibrate method for below API Level 26
            }
        }
        if(cardID=="C5577866")
        {
            gv.setshort(21)
            Toast.makeText(this, "您選擇黑色v領上衣", Toast.LENGTH_LONG).show()
        }
        if(cardID=="F5728A3D")
        {
            gv.setshirt(11)
            Toast.makeText(this, "您選擇紅色典雅長裙", Toast.LENGTH_LONG).show()
        }
        if(cardID=="F5394F32")
        {
            gv.setshirt(13)
            Toast.makeText(this, "您選擇白色短褲", Toast.LENGTH_LONG).show()
        }
    }

    private fun ByteArrayToHexString(inarray: ByteArray?): String { //把byteArray換成16進位的String
        var i: Int
        var j: Int
        var `in`: Int
        val hex = arrayOf("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F")//對照表
        var out = ""
        j = 0
        while (j < inarray!!.size) {
            `in` = inarray[j].toInt() and 0xff
            i = `in` shr 4 and 0x0f //往右邊shift四次，跑到右邊
            out += hex[i] //前面轉成16進位的結果
            i = `in` and 0x0f
            out += hex[i]
            ++j
        }
        return out
    }
    //拍照
    // 通過 intent 使用 Camera
    private fun takeImageFromCameraWithIntent() {
        println("take image from camera")

        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, ACTION_CAMERA_REQUEST_CODE)
    }

    // 通過 intent 使用 album
    private fun takeImageFromAlbumWithIntent() {
        println("take image from album")

        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, ACTION_ALBUM_REQUEST_CODE)
    }

    private val cameraAppButtonHandler = View.OnClickListener { view ->
        takeImageFromCameraWithIntent()
    }

    private val albumAppButtonHandler = View.OnClickListener { view ->
        takeImageFromAlbumWithIntent()
    }

    private fun displayImage(bitmap: Bitmap) {
        imageView.setImageBitmap(bitmap)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        println("收到 result code $requestCode")

        when(requestCode) {
            ACTION_CAMERA_REQUEST_CODE -> {
                if(resultCode == Activity.RESULT_OK && data != null){
                    displayImage(data.extras?.get("data") as Bitmap)
                }
            }

            ACTION_ALBUM_REQUEST_CODE -> {
                if(resultCode == Activity.RESULT_OK && data != null){
                    val resolver = this.contentResolver
                    val bitmap = MediaStore.Images.Media.getBitmap(resolver, data?.data)
                    displayImage(bitmap)


                }
            }
            else -> {
                println("no handler onActivityReenter")
            }
        }
    }
}
