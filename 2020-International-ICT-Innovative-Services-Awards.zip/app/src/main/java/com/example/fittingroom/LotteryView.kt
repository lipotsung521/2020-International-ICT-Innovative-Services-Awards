package com.example.fittingroom

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.os.Handler
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import android.widget.Toast
import androidx.annotation.Nullable
import androidx.core.content.ContextCompat
import com.example.fittingroom.Coupon as Coupon1

class LotteryView : View {

    /**
     * 扇形分区的颜色
     */
    private val colors =
        intArrayOf(
            R.color.red,
            R.color.yellow,
            R.color.blue,
            R.color.red,
            R.color.yellow,
            R.color.blue
        )

    /**
     * 分区的文字描述
     */
    private val prizeName =
        arrayOf("褲子9折", "服飾88折", "銘謝惠顧", "服飾85折", "上衣買二送一", "下著買一送一")

    /**
     * 扇形的角度
     */
    private val mAngel = 0f

    /**
     * 盘块的数量
     */
    private val mItems = 6

    /**
     * 扇形分区图片
     */
    private val imgs = intArrayOf(
        R.drawable.denim_shorts, R.drawable.clothes, R.drawable.f040, R.drawable.coupon2, R.drawable.clothes3
        , R.drawable.f015
    )

    /**
     * 图片对应的bitmap
     */
    private lateinit var mImgBitmap: Array<Bitmap?>

    /**
     * 圆盘的大小范围
     */
    private var mRange = RectF()

    /**
     * 圆盘的直径
     */
    private var mRadius = 0

    /**
     * 扇形分区的画笔
     */
    private var mArcPaint: Paint? = null

    /**
     * 绘制文本的画笔
     */
    private var mTextPaint: Paint? = null

    /**
     * 圆盘滚动的速度
     */
    private var mSpeed = 10000.0

    /**
     * 绘制的起始角度
     */
    private var mStartAngle = 10.0

    /**
     * 是否点击了结束按钮
     */
    private var start = false

    /**
     * 转盘的中心位置
     */
    private var mCenter = 0

    /**
     * 圆盘Padding值
     */
    private var mPadding = 0

    /**
     * 圆盘背景图片
     */
    private val mBgBitmap = BitmapFactory.decodeResource(resources, R.drawable.bg2)

    /**
     * 文字的大小
     */
    private val mTextSize = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_SP,
        20f,
        resources.displayMetrics
    )

    @SuppressLint("HandlerLeak")
    private val mHandler = Handler()

    @JvmOverloads
    constructor(
        context: Context?,
        @Nullable attrs: AttributeSet? = null
    ) : super(context, attrs) {
        init()
    }

    constructor(
        context: Context?,
        @Nullable attrs: AttributeSet?,
        defStyleAttr: Int
    ) : super(context, attrs, defStyleAttr) {
        init()
    }

    /**
     * 量测尺寸  我们将画圆盘在一个正方形之中
     */
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        //获取宽高的最小值
        val width = Math.min(measuredWidth, measuredHeight)
        //以PaddingLeft为准
        mPadding = paddingLeft
        //获取直径
        mRadius = width - mPadding * 2
        setMeasuredDimension(width, width)
        //初始化圆盘的范围
        mRange = RectF(
            mPadding.toFloat(),
            mPadding.toFloat(),
            (mRadius + mPadding).toFloat(),
            (mRadius + mPadding).toFloat()
        )
        //中心位置
        mCenter = measuredWidth / 2
    }

    /**
     * 初始化
     */
    private fun init() {
        //初始化盘块画笔
        mArcPaint = Paint()
        mArcPaint!!.isAntiAlias = true
        mArcPaint!!.isDither = true

        //初文字画笔
        mTextPaint = Paint()
        mTextPaint!!.isAntiAlias = true
        mTextPaint!!.isDither = true
        mTextPaint!!.color = Color.WHITE
        mTextPaint!!.textSize = mTextSize

        //初始化盘块中的图片
        mImgBitmap = arrayOfNulls(mItems)
        for (i in mImgBitmap.indices) {
            mImgBitmap[i] = BitmapFactory.decodeResource(resources, imgs[i])
        }
    }

    @SuppressLint("DrawAllocation")
    override fun onDraw(canvas: Canvas) {
        //1.绘制背景
        canvas.drawBitmap(
            mBgBitmap, null, RectF(
                (mPadding / 1).toFloat(),
                (mPadding / 1).toFloat()
                ,
                (measuredWidth - mPadding / 1).toFloat(),
                (measuredHeight - mPadding / 1).toFloat()
            ), null
        )
        //2.绘制盘块
        var tempAngle = mStartAngle.toInt()
        val sweepAngle = 360 / mItems.toFloat()
        //        //旋转绘制的图片
        //        ArrayList<Bitmap> bitmaps = new ArrayList<>();
        //        for (int j = 0; j < imgs.length; j++) {
        //            //获取bitmap
        //            Bitmap bitmap = BitmapFactory.decodeResource(getResources(), imgs[j]);
        //            int width = bitmap.getWidth();
        //            int height = bitmap.getHeight();
        //            Matrix matrix = new Matrix();
        //            //设置缩放值
        //            matrix.postScale(1f, 1f);
        //            //旋转的角度
        //            matrix.postRotate(sweepAngle * j);
        //            //获取旋转后的bitmap
        //            Bitmap rotateBitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height, matrix, true);
        //            //将旋转过的图片保存到列表中
        //            bitmaps.add(rotateBitmap);
        //        }
        for (i in 0 until mItems) {
            //1.绘制盘块背景
            mArcPaint!!.color = ContextCompat.getColor(context, colors[i])
            canvas.drawArc(mRange, tempAngle.toFloat(), sweepAngle, true, mArcPaint!!)


            //2.绘制盘块的文字
            val path = Path()
            path.addArc(mRange, tempAngle.toFloat(), sweepAngle)
            //通过水平偏移量使得文字居中  水平偏移量=弧度/2 - 文字宽度/2
            val textWidth = mTextPaint!!.measureText(prizeName[i])
            val hOffset =
                (mRadius * Math.PI / mItems / 2 - textWidth / 2).toFloat()
            //垂直偏移量 = 半径/6
            val vOffset = mRadius / 2 / 6.toFloat()
            canvas.drawTextOnPath(prizeName[i], path, hOffset, vOffset, mTextPaint!!)

            //3.绘制盘块上面的IMG
            //约束下图片的宽度
            val imgWidth = mRadius / 8
            //获取弧度
            val angle =
                Math.toRadians(tempAngle + sweepAngle / 2.toDouble()).toFloat()
            //将图片移动到圆弧中心位置
            val x =
                (mCenter + mRadius / 2 / 2 * Math.cos(angle.toDouble())).toFloat()
            val y =
                (mCenter + mRadius / 2 / 2 * Math.sin(angle.toDouble())).toFloat()
            //确认绘制的矩形
            val rectF =
                RectF(x - imgWidth / 2, y - imgWidth / 2, x + imgWidth / 2, y + imgWidth / 2)
            val bitmap = BitmapFactory.decodeResource(resources, imgs[i])
            canvas.drawBitmap(bitmap, null, rectF, null)
            tempAngle += sweepAngle.toInt()
        }
        if (start) {
            mStartAngle += mSpeed
            //16ms之后刷新界面
            mHandler.postDelayed(MyRunnable(), 15)
            mSpeed -= 1.0
            if (mSpeed < 10) {
                mSpeed -= 0.5
            }
            if (mSpeed < 9) {
                mSpeed -= 0.45
            }
            if (mSpeed < 8) {
                mSpeed -= 0.4
            }
            if (mSpeed < 7) {
                mSpeed -= 0.35
            }
            if (mSpeed < 6) {
                mSpeed -= 0.3
            }
            if (mSpeed < 5) {
                mSpeed -= 0.25
            }
            if (mSpeed < 4) {
                mSpeed -= 0.2
            }
            if (mSpeed < 3) {
                mSpeed -= 0.15
            }
            if (mSpeed < 2) {
                mSpeed -= 0.1
            }
            if (mSpeed < 1) {
                mSpeed -= 0.05
            }
            if (mSpeed < 0) {
                mSpeed = 0.0
                start = false
            }
        }
    }

    fun start() {
        start = true
        mSpeed = 40.0
        invalidate()
    }

    private inner class MyRunnable : Runnable {
        override fun run() {
            invalidate()
        }
    }
}

