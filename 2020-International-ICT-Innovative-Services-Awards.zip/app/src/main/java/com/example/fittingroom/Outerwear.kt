package com.example.fittingroom

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView

class Outerwear : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_outerwear)
        var correct:ImageView?=null
        correct=findViewById(R.id.nike1)
        correct?.setOnClickListener {
            val uri: Uri = Uri.parse("https://www.nike.com/tw/t/dri-fit-my-life-%E7%94%B7%E6%AC%BE%E7%B1%83%E7%90%83-t-%E6%81%A4-jmJhXp?fbclid=IwAR0tV6nHtBqGcZpbdhXNGLeoqmRUgbVu_alyUNsfYJWvB5uRcG2SLEC08GQ")
            val intent = Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent)
        }
        var outerwear_back: Button?=null
        outerwear_back=findViewById(R.id.outerwear_back)
        outerwear_back.setOnClickListener {
            var intentP39= Intent(this, fittingroom ::class.java)
            startActivityForResult(intentP39,39)
        }
    }
}